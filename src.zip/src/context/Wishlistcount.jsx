import { createContext } from "react";

const Wishlistcount = createContext()

export default Wishlistcount;