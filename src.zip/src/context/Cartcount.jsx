import { createContext } from "react";

const Cartcount = createContext()

export default Cartcount;